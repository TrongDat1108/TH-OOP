public class Cau2 {
    public static int[][] add(int[][] A, int[][] B) {
        if (A.length != B.length || A[0].length != B[0].length) {
            return null;
        }
        int result[][] = new int[A.length][A[0].length];
        for (int i = 0; i < A.length; i++) {
            for (int j = 0; j < A[i].length; j++) {
                result[i][j] = A[i][j] + B[i][j];
            }
        }
        return result;
    }

    public static int[][] mul(int[][] A, int[][] B) {
        if (A[0].length != B[0].length) {
            return null;
        }
        int[][] result = new int[A.length][B[0].length];
        for (int i = 0; i < A.length; i++) {
            for (int j = 0; j < A[0].length; j++) {
                result[i][j] = 0;
                for (int k = 0; k < A.length; k++) {
                    result[i][j] += A[i][k] * B[k][j];
                }
            }
        }
        return result;
    }

    public static void main(String[] args) {
        int[][] A = { { 1, 2, 3 }, { 2, 3, 4 } };
        int[][] B = { { 4, 5, 6 }, { 7, 8, 9 } };
        for (int i = 0; i < A.length; i++) {
            for (int j = 0; j < A[0].length; j++) {
                System.out.print(A[i][j] + " ");
            }
            System.out.println();
        }
        System.out.println();

        for (int k = 0; k < B.length; k++) {
            for (int h = 0; h < B[0].length; h++) {
                System.out.print(B[k][h] + " ");
            }
            System.out.println();
        }
        System.out.println();

        int[][] newArray = add(A, B);
        for (int f = 0; f < newArray.length; f++) {
            for (int g = 0; g < newArray[0].length; g++) {
                System.out.print(newArray[f][g] + " ");
            }
            System.out.println();
        }
        System.out.println();

        int[][] newArray2 = mul(A, B);
        for (int t = 0; t < A.length; t++) {
            for (int z = 0; z < A[0].length; z++) {
                System.out.print(newArray2[t][z] + " ");
            }
            System.out.println();
        }
    }
}