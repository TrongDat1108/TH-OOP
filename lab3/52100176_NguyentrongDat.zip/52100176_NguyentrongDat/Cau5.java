public class Cau5 {
    public static String[][] countWords(String paragraph) {
        String[] temp = paragraph.trim().split("\\W+");
        String[][] index = new String[temp.length][2];
        for (int i = 0; i < temp.length; i++) {
            for (int j = 0; j < 2; j++) {
                if (j == 0) {
                    index[i][j] = temp[i];
                } else {
                    index[i][j] = "1";
                }
            }
        }
        int count = 0;
        for (int k = 0; k < index.length - 1; k++) {
            for (int h = k + 1; h < index.length; h++) {
                if (index[k][0].compareToIgnoreCase(index[h][0]) == 0) {
                    index[k][1] = String.valueOf(Integer.parseInt(index[k][1]) + 1);
                    index[h][1] = String.valueOf(Integer.parseInt(index[h][1]) - 1);
                }
            }
        }
        int f = 0;
        while (f < index.length) {
            if (index[f][1].compareToIgnoreCase("0") > 0) {
                count++;
            }
            f++;
        }
        String[][] result = new String[count][2];
        f = 0;
        for (int d = 0; d < index.length; d++) {
            if (index[d][1].compareToIgnoreCase("0") > 0) {
                result[f][0] = index[d][0];
                result[f][1] = index[d][1];
                if (f == result.length)
                    break;
                f++;
            }
        }
        return result;
    }

    public static void main(String[] args) {
        String paragraph = "You are living on a Plane. What you style Flatland is the vast level surface of what I may call a fluid, on, or in, the top of which you and your countrymen move about, without rising above it or falling below it.";
        String[][] result = countWords(paragraph);
        for (String[] string : result) {
            System.out.println('\'' + string[0] + "\' : " + string[1]);
        }
    }
}
