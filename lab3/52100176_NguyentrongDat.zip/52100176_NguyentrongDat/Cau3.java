import java.util.Scanner;

public class Cau3 {
    public static String splitName(String fullName) {
        int firstNumber = fullName.indexOf(" ");
        int lastNumber = fullName.lastIndexOf(" ");
        String firstName = fullName.substring(0, firstNumber);
        String lastName = fullName.substring(lastNumber);
        return firstName + lastName;
    }

    public static String middleOfName(String fullName) {
        int firstNumber = fullName.indexOf(" ");
        int lastNumber = fullName.lastIndexOf(" ");
        String middleOfName = fullName.substring(firstNumber + 1, lastNumber);
        return middleOfName;
    }

    public static String capitalizeFullName(String fullName) {
        String temp = "";
        String[] index = fullName.split(" ");
        for (String check : index) {
            String index2 = check.substring(0, 1).toUpperCase() + check.substring(1);
            temp = temp + " " + index2;
        }
        return temp.trim();
    }

    public static String upperCaseVowels(String fullName) {
        String temp = "";
        String newFullnName = fullName.toLowerCase();
        for (int i = 0; i < fullName.length(); i++) {
            char newChar = newFullnName.charAt(i);
            if (newChar == 'a' || newChar == 'e' || newChar == 'i' || newChar == 'o' || newChar == 'u') {
                temp = temp + (char) (newChar - 32);
                continue;
            }
            temp = temp + newChar;
        }
        return temp;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter you full name: ");
        String fullName = input.nextLine();
        System.out.println("The first and last name are: " + splitName(fullName));
        System.out.println("The middle name are: " + middleOfName(fullName));
        System.out.println("The capitalize full name are: " + capitalizeFullName(fullName));
        System.out.println("The uppercase all vowels and lowercase all consonants are: " + upperCaseVowels(fullName));
        input.close();
    }
}
