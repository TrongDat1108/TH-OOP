import java.util.Scanner;

public class Cau1 {

    public static boolean removeFirstElement(int[] array, int k) {
        if (array.length == 0)
            return false;
        int pos = -1;
        for (int i = 0; i < array.length; i++) {
            if (array[i] == k) {
                pos = i;
                break;
            }
        }
        if (pos == -1) {
            return false;
        }
        for (int i = pos; i < array.length - 1; i++) {
            array[i] = array[i + 1];
        }
        return true;
    }

    public static int[] insertX(int k, int[] array, int pos) {
        int j;
        int[] newArray = new int[array.length];

        for (int i = j = 0; i < array.length; i++, j++) {
            newArray[j] = array[i];
            if (i == pos) {
                newArray[j] = k;
            }
        }
        return newArray;
    }

    public static int exit(int[] a, int temp) {
        for (int i = temp - 1; i >= 0; i--) {
            if (a[i] == a[temp]) {
                return 1;
            }
        }
        return 0;
    }

    public static int countDupElement(int[] array) {
        int count = 0;
        for (int i = 0; i < array.length; i++) {
            int index = 0;
            if (exit(array, i) == 1) {
                for (int j = i + 1; j < array.length; j++) {
                    if (array[j] == array[i]) {
                        index = 1;
                    }
                }
                if (index == 1)
                    continue;
                count++;
            }
        }
        return count;
    }

    public static int[] findDupElements(int[] array) {
        int count = countDupElement(array);
        System.out.println("Count: " + count);
        int[] temp = new int[array.length];
        int[] index = new int[count];
        for (int i = 0, j = 0; i < array.length; i++) {
            boolean check = false;
            if (temp[i] == 0) {
                temp[i] = 1;
                for (int k = i + 1; k < array.length; k++) {
                    if (array[k] == array[i]) {
                        temp[k] = 1;
                        check = true;
                    }
                }
            }
            if (check) {
                index[j++] = array[i];
            }
        }
        return index;
    }

    public static int[] selectionSort(int[] array) {
        for (int i = 0; i < array.length - 1; i++) {
            int min = i;
            for (int j = i + 1; j < array.length; j++) {
                if (array[j] == array[min]) {
                    min = j;
                }
            }
            int temp = array[min];
            array[min] = array[i];
            array[i] = temp;
        }
        return array;
    }

    public static int[] removeDupElement(int[] array) {
        int temp = 1;
        for (int i = 1; i < array.length; i++) {
            int index = array[i];
            for (int j = 0; j < temp; j++) {
                if (array[j] == index) {
                    break;
                }
                if (j == temp - 1) {
                    array[temp++] = index;
                    break;
                }
            }
        }
        int[] newArray = new int[temp];
        for (int i = 0; i < temp; i++) {
            newArray[i] = array[i];
        }
        return newArray;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int array[] = { 2, 5, 9, 1, 7, 8, 3, 4, 6, 1, 3 };

        System.out.print("Enter k: ");
        int k = input.nextInt();
        System.out.println(removeFirstElement(array, k));
        System.out.println();

        System.out.print("Enter value: ");
        int value = input.nextInt();
        System.out.print("Enter position: ");
        int position = input.nextInt();
        int[] newArray = insertX(value, array, position);
        System.out.print("Array after insert: ");
        System.out.print("[ ");
        for (int temp : newArray) {
            System.out.print(temp + " ");
        }
        System.out.print("]");
        System.out.println();

        int[] newArray2 = findDupElements(array);
        System.out.print("Array after find duplicate elements: ");
        System.out.print("[ ");
        for (int temp2 : newArray2) {
            System.out.print(temp2 + " ");
        }
        System.out.print("]");
        System.out.println();

        int[] newArray3 = removeDupElement(array);
        System.out.print("Array after remove duplicate elements: ");
        System.out.print("[ ");
        for (int temp3 : newArray3) {
            System.out.print(temp3 + " ");
        }
        System.out.print("]");
        System.out.println();
        input.close();
    }

}
