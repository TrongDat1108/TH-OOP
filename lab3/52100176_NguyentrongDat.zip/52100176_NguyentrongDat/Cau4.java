import java.util.Scanner;

public class Cau4 {
    public static int lengthOfString(String string) {
        return string.length();
    }

    public static int countWordInString(String string) {
        String[] temp = string.split(" ");
        return temp.length;
    }

    public static String concatanateOneString(String firstString, String secondString) {
        return firstString + secondString;
    }

    public static boolean checkPalindrome(String string) {
        String temp = "";
        for (int i = string.length() - 1; i >= 0; i--) {
            temp = temp + string.charAt(i);
        }
        if (temp.equalsIgnoreCase(string) == true) {
            return true;
        }
        return false;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter the first string: ");
        String firstString = input.nextLine();

        System.out.println("Length of string: " + lengthOfString(firstString));
        System.out.println("Length of words: " + countWordInString(firstString));

        System.out.print("Enter the second string: ");
        String secondString = input.nextLine();

        System.out.println(
                "Concatenate the first string to second string: " + concatanateOneString(firstString, secondString));

        System.out.println("Check parindrome: " + checkPalindrome(firstString));
        input.close();

    }
}
