import java.util.Scanner;

public class Cau11 {
    public static int countNumber(int number) {
        int count = 0;

        while (number > 1) {
            number = number / 10;
            count++;
        }

        return count + 1;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter your number: ");
        int number = input.nextInt();
        System.out.println("Count number of digits in a number: " + countNumber(number));
        input.close();
    }
}
