public class Cau1 {
    public static void main(String[] args) {
        System.out.println("My name: Nguyen Trong Dat");
        System.out.println("Date of birth: 11/08/2003");
        System.out.println("ID: 52100176");
    }
}
