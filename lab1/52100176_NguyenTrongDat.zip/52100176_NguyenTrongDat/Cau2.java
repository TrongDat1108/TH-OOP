import java.util.*;

public class Cau2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Nhap gia tri base: ");
        double base = input.nextDouble();

        System.out.println("Nhap gia tri height: ");
        double height = input.nextDouble();

        double area = 0;

        area = 1.0 / 2.0 * base * height;

        System.out.printf("Dien tich la: %f", area);

        input.close();
    }
}
