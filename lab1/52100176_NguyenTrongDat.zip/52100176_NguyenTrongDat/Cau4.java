public class Cau4 {
    public static double convertFToC(double f) {
        return (double) 5 / 9 * (f - 32);
    }

    public static double convertCToF(double c) {
        return (double) 9 / 5 * c + 32;
    }

    public static void main(String[] args) {
        System.out.println("The temperature from Fahrenheit to Celsius " + convertFToC(95));
        System.out.println("the temperature from Celsius to Fahrenheit " + convertCToF(35));
    }
}
