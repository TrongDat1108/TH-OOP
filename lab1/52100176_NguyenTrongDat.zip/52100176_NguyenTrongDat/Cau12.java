import java.util.Scanner;

public class Cau12 {
    public static int reverseNumber(int number) {
        int temp = 0;
        int index = 0;
        while (number > 0) {
            index = number % 10;
            temp = temp * 10 + index;
            number = number / 10;
        }
        return temp;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Nhap so nguyen: ");
        int number = input.nextInt();

        System.out.println(reverseNumber(number) + " is a reverse number of " + number);

        input.close();
    }
}
