import java.util.Scanner;

public class Cau9 {
    public static void hailstone(int number) {
        while (number != 1) {
            if (number % 2 == 0) {
                System.out.println(number + " is even, so we take n/2: " + number / 2);
                number /= 2;
            } else {
                System.out.println(number + " is odd, so we take 3*n+1: " + (number * 3 + 1));
                number = number * 3 + 1;
            }
        }
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.printf("Enter a Number: ");
        int number = input.nextInt();
        hailstone(number);
        input.close();
    }
}
