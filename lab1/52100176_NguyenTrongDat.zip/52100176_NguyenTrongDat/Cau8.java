import java.util.Scanner;

public class Cau8 {
    public static int cauA(int n) {
        if (n == 0)
            return 1;
        else
            return n + cauA(n - 1);
    }

    public static int cauB(int n) {
        if (n == 0)
            return 1;
        else
            return n * cauB(n - 1);
    }

    public static int cauC(int n) {
        int c = 0;
        for (int i = 0; i <= n; i++) {
            c = c + (int) Math.pow(2, i);
        }
        return c;
    }

    public static double cauD(int n) {
        double d = 0;
        for (int i = 0; i <= n; i++) {
            if (i != 0)
                d = d + (1.0 / (2 * i));
        }
        return d;
    }

    public static int cauE(int n) {
        int e = 0;
        for (int i = 0; i <= n; i++) {
            if (i != 0)
                e = e + (int) Math.pow(i, 2);
        }
        return e;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter n: ");
        int n = input.nextInt();

        System.out.println("The result of cau A: " + cauA(n));
        System.out.println("The result of cau B: " + cauB(n));
        System.out.println("The result of cau C: " + cauC(n));
        System.out.println("The result of cau D: " + cauD(n));
        System.out.println("The result of cau E: " + cauE(n));

        input.close();
    }
}
