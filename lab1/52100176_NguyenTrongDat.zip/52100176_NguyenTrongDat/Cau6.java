import java.util.Scanner;

public class Cau6 {
    public static int minimum(int num1, int num2, int num3) {
        if (num1 < num2 && num1 < num3)
            return num1;
        else if (num2 < num1 && num2 < num3)
            return num2;
        else
            return num3;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Nhap so dau tien: ");
        int num1 = input.nextInt();
        System.out.print("Nhap so thu hai: ");
        int num2 = input.nextInt();
        System.out.print("Nhap so thu ba: ");
        int num3 = input.nextInt();

        System.out.println("So nho nhat trong ba so: " + minimum(num1, num2, num3));

        input.close();
    }
}