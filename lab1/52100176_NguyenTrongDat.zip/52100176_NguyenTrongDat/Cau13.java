import java.util.Scanner;

public class Cau13 {
    public static void palindromeNumber(int number) {
        int sum = 0, temp, step;

        temp = number;
        while (number > 0) {
            step = number % 10;
            sum = (sum * 10) + step;
            number = number / 10;
        }

        if (temp == sum) {
            System.out.println(temp + " is a palindrome number");
        } else
            System.out.println(temp + "is not a palindrome number");
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter your number: ");
        int number = input.nextInt();

        palindromeNumber(number);
        input.close();
    }
}
