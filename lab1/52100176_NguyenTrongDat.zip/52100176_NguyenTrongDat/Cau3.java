import java.util.Scanner;

public class Cau3 {
    public static double div(double x, double y) {
        return x % y;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Nhap gia tri x: ");
        double x = input.nextDouble();

        System.out.print("Nhap gia tri y: ");
        double y = input.nextDouble();

        System.out.println("Gia tri sau chia la " + div(x, y));

        input.close();
    }
}
