import java.util.Scanner;

public class Cau10 {
    public static int digits(int number) {
        int tmp = 0, first;
        int temp = number;

        int last = temp % 10;
        while (number > 0) {
            tmp = number % 10;
            number = number / 10;
        }

        first = tmp;

        int sum = first + last;
        return sum;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter your number: ");
        int number = input.nextInt();

        System.out.println("Sum the first digit and the last digit of a number: " + digits(number));
        input.close();
    }

}
