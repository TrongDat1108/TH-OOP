public class TestRegualrPolygon {
    public static void main(String[] args) {
        RegularPolygon polygon = new RegularPolygon("vuong", 4, 5);

        System.out.println(polygon.toString());
    }
}
