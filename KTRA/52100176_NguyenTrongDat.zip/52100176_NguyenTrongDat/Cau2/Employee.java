public class Employee {
    private String eID;
    private String eName;
    private int eSalary;
    private String eDept;

    public Employee(String eID, String eName, int eSalary, String eDept) {
        this.eID = eID;
        this.eName = eName;
        this.eSalary = eSalary;
        if (eDept.equalsIgnoreCase("Accounting") == true || eDept.equalsIgnoreCase("Administration") == true
                || eDept.equalsIgnoreCase("Human Resources") == true
                || eDept.equalsIgnoreCase("Customer Service") == true) {
            this.eDept = eDept;
        } else {
            this.eDept = "Administration";
        }
    }

    public double getBonus() {
        double newESalary = 0;
        if (this.eDept == "Administration") {
            newESalary = this.eSalary * 0.5;
        } else if (this.eDept == "Accounting" || this.eDept == "Human Resources") {
            newESalary = this.eSalary * 0.3;
        } else {
            newESalary = this.eSalary * 0.1;
        }
        return newESalary;
    }

    public double totalSalary(int numOfWorkingDays) {
        double Total = 0;
        if (numOfWorkingDays < 20) {
            Total = (eSalary * numOfWorkingDays) + this.getBonus();
        } else if (numOfWorkingDays >= 20) {
            Total = ((eSalary * numOfWorkingDays) + this.getBonus())
                    + (0.05 * ((eSalary * numOfWorkingDays) + this.getBonus()));
        }
        return Total;
    }

    public String geteID() {
        return eID;
    }

    public void seteID(String eID) {
        this.eID = eID;
    }

    public String geteName() {
        return eName;
    }

    public void seteName(String eName) {
        this.eName = eName;
    }

    public int geteSalary() {
        return eSalary;
    }

    public void seteSalary(int eSalary) {
        this.eSalary = eSalary;
    }

    public String geteDept() {
        return eDept;
    }

    public void seteDept(String eDept) {
        this.eDept = eDept;
    }

}