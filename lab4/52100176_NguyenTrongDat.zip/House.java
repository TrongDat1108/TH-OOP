public class House {
    private String houseCode;
    private int numOfBedRooms;
    private boolean hasSwimmingPool;
    private double area;
    private double costPerSquareMeter;

    public House() {
        houseCode = "A01";
        numOfBedRooms = 2;
        hasSwimmingPool = false;
        area = 0.0d;
        costPerSquareMeter = 0.0d;
    }

    public House(String houseCode, int numOfBedRooms, boolean hasSwimmingPool, double area, double costPerSquareMeter) {
        this.houseCode = houseCode;
        this.numOfBedRooms = numOfBedRooms;
        this.hasSwimmingPool = hasSwimmingPool;
        this.area = area;
        this.costPerSquareMeter = costPerSquareMeter;
    }

    public String getHouseCode() {
        return this.houseCode;
    }

    public int getNumOfBedRooms() {
        return this.numOfBedRooms;
    }

    public boolean getHasSwimmingPool() {
        return this.hasSwimmingPool;
    }

    public double getArea() {
        return this.area;
    }

    public double getCostPerSquareMeter() {
        return this.costPerSquareMeter;
    }

    public void setHouseCode(String houseCode) {
        this.houseCode = houseCode;
    }

    public void setNumOfBedRooms(int numOfBedRooms) {
        this.numOfBedRooms = numOfBedRooms;
    }

    public void setHasSwimmingPool(boolean hasSwimmingPool) {
        this.hasSwimmingPool = hasSwimmingPool;
    }

    public void setArea(double area) {
        this.area = area;
    }

    public void setCostPerSquareMeter(double costPerSquareMeter) {
        this.costPerSquareMeter = costPerSquareMeter;
    }

    public double calculateSellingPrice() {
        double sellingPrice = 0.0d;
        double subTotal = this.area * this.costPerSquareMeter;
        if (this.hasSwimmingPool) {

            sellingPrice = subTotal * 1.1;
        } else {
            sellingPrice = subTotal;
        }
        return sellingPrice * 1.15;
    }

    public String toString() {
        return "House[houseCode = " + this.houseCode + ", numOfBedRooms = " + this.numOfBedRooms
                + ", hasSwimmingPool = " + this.hasSwimmingPool + ", sellingPrice = " + calculateSellingPrice() + "]";
    }
}
