public class Fraction {
    private int numerator;
    private int denominator;

    public Fraction() {
    }

    public Fraction(int numerator, int denominator) {
        this.numerator = numerator;
        this.denominator = denominator;
    }

    public Fraction(Fraction f) {
        this.numerator = f.numerator;
        this.denominator = f.denominator;
    }

    public Fraction add(Fraction f) {
        Fraction sum = new Fraction();
        sum.numerator = f.numerator * this.denominator + this.numerator * f.denominator;
        sum.denominator = f.denominator * this.denominator;
        return sum;
    }

    public Fraction sub(Fraction f) {
        Fraction result = new Fraction();
        result.numerator = f.numerator * this.denominator - this.numerator * f.denominator;
        result.denominator = f.denominator * this.denominator;
        return result;
    }

    public Fraction mul(Fraction f) {
        Fraction result = new Fraction();
        result.numerator = f.numerator * this.numerator;
        result.denominator = f.denominator * this.denominator;
        return result;
    }

    public Fraction div(Fraction f) {
        Fraction result = new Fraction();
        result.numerator = f.numerator * this.denominator;
        result.denominator = f.denominator * this.numerator;
        return result;
    }

    public void reducer() {
    }

    public String toString() {
        return "Fraction[ Numerator = " + this.numerator + ", Denominator = " + this.denominator + "]";
    }
}